﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AcademicStanding
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Title_Label = New System.Windows.Forms.Label()
        Me.StandingLabel = New System.Windows.Forms.Label()
        Me.Grades_15_Button = New System.Windows.Forms.Button()
        Me.Grades_15_Panel = New System.Windows.Forms.TableLayoutPanel()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Term_Stats_Panel = New System.Windows.Forms.TableLayoutPanel()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Term_Stats_Button = New System.Windows.Forms.Button()
        Me.Grades_15_Panel.SuspendLayout()
        Me.Term_Stats_Panel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Title_Label
        '
        Me.Title_Label.AutoSize = True
        Me.Title_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Title_Label.Location = New System.Drawing.Point(12, 17)
        Me.Title_Label.Name = "Title_Label"
        Me.Title_Label.Size = New System.Drawing.Size(235, 32)
        Me.Title_Label.TabIndex = 0
        Me.Title_Label.Text = "View My Grades"
        '
        'StandingLabel
        '
        Me.StandingLabel.AutoSize = True
        Me.StandingLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StandingLabel.Location = New System.Drawing.Point(15, 67)
        Me.StandingLabel.Name = "StandingLabel"
        Me.StandingLabel.Size = New System.Drawing.Size(168, 29)
        Me.StandingLabel.TabIndex = 1
        Me.StandingLabel.Text = "StandingLabel"
        '
        'Grades_15_Button
        '
        Me.Grades_15_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Grades_15_Button.Location = New System.Drawing.Point(23, 117)
        Me.Grades_15_Button.Name = "Grades_15_Button"
        Me.Grades_15_Button.Size = New System.Drawing.Size(1015, 36)
        Me.Grades_15_Button.TabIndex = 2
        Me.Grades_15_Button.Text = "Class Grades - 2015"
        Me.Grades_15_Button.UseVisualStyleBackColor = True
        '
        'Grades_15_Panel
        '
        Me.Grades_15_Panel.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Grades_15_Panel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.Grades_15_Panel.ColumnCount = 6
        Me.Grades_15_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.03132!))
        Me.Grades_15_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.96868!))
        Me.Grades_15_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 77.0!))
        Me.Grades_15_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190.0!))
        Me.Grades_15_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 85.0!))
        Me.Grades_15_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 205.0!))
        Me.Grades_15_Panel.Controls.Add(Me.Label89, 0, 10)
        Me.Grades_15_Panel.Controls.Add(Me.Label2, 1, 0)
        Me.Grades_15_Panel.Controls.Add(Me.Label1, 0, 0)
        Me.Grades_15_Panel.Controls.Add(Me.Label3, 2, 0)
        Me.Grades_15_Panel.Controls.Add(Me.Label4, 3, 0)
        Me.Grades_15_Panel.Controls.Add(Me.Label5, 4, 0)
        Me.Grades_15_Panel.Controls.Add(Me.Label6, 5, 0)
        Me.Grades_15_Panel.Controls.Add(Me.Label7, 0, 1)
        Me.Grades_15_Panel.Controls.Add(Me.Label8, 0, 2)
        Me.Grades_15_Panel.Controls.Add(Me.Label9, 0, 3)
        Me.Grades_15_Panel.Controls.Add(Me.Label12, 0, 6)
        Me.Grades_15_Panel.Controls.Add(Me.Label13, 0, 7)
        Me.Grades_15_Panel.Controls.Add(Me.Label14, 0, 8)
        Me.Grades_15_Panel.Controls.Add(Me.Label15, 0, 9)
        Me.Grades_15_Panel.Controls.Add(Me.Label11, 0, 4)
        Me.Grades_15_Panel.Controls.Add(Me.Label10, 0, 5)
        Me.Grades_15_Panel.Controls.Add(Me.Label16, 1, 1)
        Me.Grades_15_Panel.Controls.Add(Me.Label18, 1, 2)
        Me.Grades_15_Panel.Controls.Add(Me.Label19, 1, 3)
        Me.Grades_15_Panel.Controls.Add(Me.Label20, 1, 4)
        Me.Grades_15_Panel.Controls.Add(Me.Label21, 1, 5)
        Me.Grades_15_Panel.Controls.Add(Me.Label22, 1, 6)
        Me.Grades_15_Panel.Controls.Add(Me.Label23, 1, 7)
        Me.Grades_15_Panel.Controls.Add(Me.Label17, 2, 1)
        Me.Grades_15_Panel.Controls.Add(Me.Label25, 2, 2)
        Me.Grades_15_Panel.Controls.Add(Me.Label26, 2, 3)
        Me.Grades_15_Panel.Controls.Add(Me.Label27, 2, 4)
        Me.Grades_15_Panel.Controls.Add(Me.Label28, 2, 5)
        Me.Grades_15_Panel.Controls.Add(Me.Label29, 2, 6)
        Me.Grades_15_Panel.Controls.Add(Me.Label30, 2, 7)
        Me.Grades_15_Panel.Controls.Add(Me.Label31, 2, 8)
        Me.Grades_15_Panel.Controls.Add(Me.Label32, 2, 9)
        Me.Grades_15_Panel.Controls.Add(Me.Label33, 2, 10)
        Me.Grades_15_Panel.Controls.Add(Me.Label34, 3, 1)
        Me.Grades_15_Panel.Controls.Add(Me.Label35, 3, 2)
        Me.Grades_15_Panel.Controls.Add(Me.Label36, 3, 3)
        Me.Grades_15_Panel.Controls.Add(Me.Label37, 3, 4)
        Me.Grades_15_Panel.Controls.Add(Me.Label38, 3, 5)
        Me.Grades_15_Panel.Controls.Add(Me.Label39, 3, 6)
        Me.Grades_15_Panel.Controls.Add(Me.Label40, 3, 7)
        Me.Grades_15_Panel.Controls.Add(Me.Label41, 3, 8)
        Me.Grades_15_Panel.Controls.Add(Me.Label42, 3, 9)
        Me.Grades_15_Panel.Controls.Add(Me.Label43, 3, 10)
        Me.Grades_15_Panel.Controls.Add(Me.Label45, 5, 6)
        Me.Grades_15_Panel.Controls.Add(Me.Label44, 4, 6)
        Me.Grades_15_Panel.Controls.Add(Me.Label46, 4, 7)
        Me.Grades_15_Panel.Controls.Add(Me.Label47, 5, 7)
        Me.Grades_15_Panel.Controls.Add(Me.Label48, 5, 5)
        Me.Grades_15_Panel.Controls.Add(Me.Label49, 4, 5)
        Me.Grades_15_Panel.Controls.Add(Me.Label50, 4, 4)
        Me.Grades_15_Panel.Controls.Add(Me.Label51, 4, 3)
        Me.Grades_15_Panel.Controls.Add(Me.Label52, 4, 2)
        Me.Grades_15_Panel.Controls.Add(Me.Label53, 4, 1)
        Me.Grades_15_Panel.Controls.Add(Me.Label54, 4, 8)
        Me.Grades_15_Panel.Controls.Add(Me.Label55, 4, 9)
        Me.Grades_15_Panel.Controls.Add(Me.Label56, 4, 10)
        Me.Grades_15_Panel.Controls.Add(Me.Label57, 5, 1)
        Me.Grades_15_Panel.Controls.Add(Me.Label58, 5, 2)
        Me.Grades_15_Panel.Controls.Add(Me.Label59, 5, 3)
        Me.Grades_15_Panel.Controls.Add(Me.Label60, 5, 4)
        Me.Grades_15_Panel.Controls.Add(Me.Label61, 5, 8)
        Me.Grades_15_Panel.Controls.Add(Me.Label24, 0, 10)
        Me.Grades_15_Panel.Controls.Add(Me.Label62, 5, 9)
        Me.Grades_15_Panel.Controls.Add(Me.Label63, 5, 10)
        Me.Grades_15_Panel.Controls.Add(Me.Label87, 1, 8)
        Me.Grades_15_Panel.Controls.Add(Me.Label88, 1, 9)
        Me.Grades_15_Panel.Location = New System.Drawing.Point(23, 172)
        Me.Grades_15_Panel.Name = "Grades_15_Panel"
        Me.Grades_15_Panel.RowCount = 11
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Grades_15_Panel.Size = New System.Drawing.Size(1015, 346)
        Me.Grades_15_Panel.TabIndex = 5
        '
        'Label89
        '
        Me.Label89.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(193, 318)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(239, 24)
        Me.Label89.TabIndex = 67
        Me.Label89.Text = "Perspectives in Psychology"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(252, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(120, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Description"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(42, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Course "
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(461, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Units"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(582, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 25)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Grading"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(729, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 25)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Grade"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(842, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(137, 25)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Grade Points"
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(45, 39)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 24)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "CPS 109"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(45, 70)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 24)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "CPS 209"
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(45, 101)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 24)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "CPS 213"
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(43, 194)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(87, 24)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "MTH 110"
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(43, 225)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 24)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "MTH 207"
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(45, 256)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 24)
        Me.Label14.TabIndex = 14
        Me.Label14.Text = "PCS 110"
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(46, 287)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(81, 24)
        Me.Label15.TabIndex = 15
        Me.Label15.Text = "PSY 105"
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(45, 132)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(82, 24)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "CPS 310"
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(45, 163)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(82, 24)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "CPS 412"
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(224, 39)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(176, 24)
        Me.Label16.TabIndex = 16
        Me.Label16.Text = "Computer Science I"
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(222, 70)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(180, 24)
        Me.Label18.TabIndex = 18
        Me.Label18.Text = "Computer Science II"
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(206, 101)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(213, 24)
        Me.Label19.TabIndex = 19
        Me.Label19.Text = "Computer Organization I"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(204, 132)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(217, 24)
        Me.Label20.TabIndex = 20
        Me.Label20.Text = "Computer Organization II"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(180, 163)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(264, 24)
        Me.Label21.TabIndex = 21
        Me.Label21.Text = "Social Issues, Ethics and Proff."
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(246, 194)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(133, 24)
        Me.Label22.TabIndex = 22
        Me.Label22.Text = "Discrete Math I"
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(179, 225)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(267, 24)
        Me.Label23.TabIndex = 23
        Me.Label23.Text = "Calculus and Comp. Methods I"
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(469, 39)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 24)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "1.00"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(469, 70)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(45, 24)
        Me.Label25.TabIndex = 26
        Me.Label25.Text = "1.00"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(469, 101)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(45, 24)
        Me.Label26.TabIndex = 27
        Me.Label26.Text = "1.00"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(469, 132)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(45, 24)
        Me.Label27.TabIndex = 28
        Me.Label27.Text = "1.00"
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(469, 163)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(45, 24)
        Me.Label28.TabIndex = 29
        Me.Label28.Text = "1.00"
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Red
        Me.Label29.Location = New System.Drawing.Point(469, 194)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(45, 24)
        Me.Label29.TabIndex = 30
        Me.Label29.Text = "1.00"
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(469, 225)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(45, 24)
        Me.Label30.TabIndex = 31
        Me.Label30.Text = "1.00"
        '
        'Label31
        '
        Me.Label31.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(469, 256)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(45, 24)
        Me.Label31.TabIndex = 32
        Me.Label31.Text = "1.00"
        '
        'Label32
        '
        Me.Label32.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(469, 287)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(45, 24)
        Me.Label32.TabIndex = 33
        Me.Label32.Text = "1.00"
        '
        'Label33
        '
        Me.Label33.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(469, 318)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(45, 24)
        Me.Label33.TabIndex = 34
        Me.Label33.Text = "1.00"
        '
        'Label34
        '
        Me.Label34.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(589, 39)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(73, 24)
        Me.Label34.TabIndex = 35
        Me.Label34.Text = "Graded"
        '
        'Label35
        '
        Me.Label35.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(589, 70)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(73, 24)
        Me.Label35.TabIndex = 36
        Me.Label35.Text = "Graded"
        '
        'Label36
        '
        Me.Label36.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(589, 101)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(73, 24)
        Me.Label36.TabIndex = 37
        Me.Label36.Text = "Graded"
        '
        'Label37
        '
        Me.Label37.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(589, 132)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(73, 24)
        Me.Label37.TabIndex = 38
        Me.Label37.Text = "Graded"
        '
        'Label38
        '
        Me.Label38.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(589, 163)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(73, 24)
        Me.Label38.TabIndex = 39
        Me.Label38.Text = "Graded"
        '
        'Label39
        '
        Me.Label39.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Red
        Me.Label39.Location = New System.Drawing.Point(589, 194)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(73, 24)
        Me.Label39.TabIndex = 40
        Me.Label39.Text = "Graded"
        '
        'Label40
        '
        Me.Label40.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(589, 225)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(73, 24)
        Me.Label40.TabIndex = 41
        Me.Label40.Text = "Graded"
        '
        'Label41
        '
        Me.Label41.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(589, 256)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(73, 24)
        Me.Label41.TabIndex = 42
        Me.Label41.Text = "Graded"
        '
        'Label42
        '
        Me.Label42.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(589, 287)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(73, 24)
        Me.Label42.TabIndex = 43
        Me.Label42.Text = "Graded"
        '
        'Label43
        '
        Me.Label43.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(589, 318)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(73, 24)
        Me.Label43.TabIndex = 44
        Me.Label43.Text = "Graded"
        '
        'Label45
        '
        Me.Label45.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Red
        Me.Label45.Location = New System.Drawing.Point(888, 194)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(45, 24)
        Me.Label45.TabIndex = 46
        Me.Label45.Text = "1.27"
        '
        'Label44
        '
        Me.Label44.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Red
        Me.Label44.Location = New System.Drawing.Point(753, 194)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(22, 24)
        Me.Label44.TabIndex = 45
        Me.Label44.Text = "F"
        '
        'Label46
        '
        Me.Label46.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(753, 225)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(22, 24)
        Me.Label46.TabIndex = 47
        Me.Label46.Text = "B"
        '
        'Label47
        '
        Me.Label47.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(888, 225)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(45, 24)
        Me.Label47.TabIndex = 48
        Me.Label47.Text = "3.27"
        '
        'Label48
        '
        Me.Label48.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(888, 163)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(45, 24)
        Me.Label48.TabIndex = 49
        Me.Label48.Text = "3.00"
        '
        'Label49
        '
        Me.Label49.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(753, 163)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(22, 24)
        Me.Label49.TabIndex = 50
        Me.Label49.Text = "B"
        '
        'Label50
        '
        Me.Label50.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(750, 132)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(29, 24)
        Me.Label50.TabIndex = 51
        Me.Label50.Text = "A-"
        '
        'Label51
        '
        Me.Label51.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(753, 101)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(22, 24)
        Me.Label51.TabIndex = 52
        Me.Label51.Text = "B"
        '
        'Label52
        '
        Me.Label52.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(750, 70)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(28, 24)
        Me.Label52.TabIndex = 53
        Me.Label52.Text = "B-"
        '
        'Label53
        '
        Me.Label53.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.Location = New System.Drawing.Point(753, 39)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(22, 24)
        Me.Label53.TabIndex = 54
        Me.Label53.Text = "B"
        '
        'Label54
        '
        Me.Label54.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(753, 256)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(22, 24)
        Me.Label54.TabIndex = 55
        Me.Label54.Text = "B"
        '
        'Label55
        '
        Me.Label55.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(753, 287)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(23, 24)
        Me.Label55.TabIndex = 56
        Me.Label55.Text = "C"
        '
        'Label56
        '
        Me.Label56.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(748, 318)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(33, 24)
        Me.Label56.TabIndex = 57
        Me.Label56.Text = "B+"
        '
        'Label57
        '
        Me.Label57.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(888, 39)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(45, 24)
        Me.Label57.TabIndex = 58
        Me.Label57.Text = "3.00"
        '
        'Label58
        '
        Me.Label58.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(888, 70)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(45, 24)
        Me.Label58.TabIndex = 59
        Me.Label58.Text = "2.67"
        '
        'Label59
        '
        Me.Label59.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(888, 101)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(45, 24)
        Me.Label59.TabIndex = 60
        Me.Label59.Text = "3.27"
        '
        'Label60
        '
        Me.Label60.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(888, 132)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(45, 24)
        Me.Label60.TabIndex = 61
        Me.Label60.Text = "3.67"
        '
        'Label61
        '
        Me.Label61.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(888, 256)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(45, 24)
        Me.Label61.TabIndex = 62
        Me.Label61.Text = "3.27"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(46, 318)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(81, 24)
        Me.Label24.TabIndex = 25
        Me.Label24.Text = "PSY 304"
        '
        'Label62
        '
        Me.Label62.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(888, 287)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(45, 24)
        Me.Label62.TabIndex = 63
        Me.Label62.Text = "2.27"
        '
        'Label63
        '
        Me.Label63.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(888, 318)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(45, 24)
        Me.Label63.TabIndex = 64
        Me.Label63.Text = "3.33"
        '
        'Label87
        '
        Me.Label87.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(275, 256)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(74, 24)
        Me.Label87.TabIndex = 65
        Me.Label87.Text = "Physics"
        '
        'Label88
        '
        Me.Label88.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(214, 287)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(196, 24)
        Me.Label88.TabIndex = 66
        Me.Label88.Text = "Psychology of Gender"
        '
        'Term_Stats_Panel
        '
        Me.Term_Stats_Panel.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Term_Stats_Panel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.[Single]
        Me.Term_Stats_Panel.ColumnCount = 3
        Me.Term_Stats_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.8125!))
        Me.Term_Stats_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.1875!))
        Me.Term_Stats_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 268.0!))
        Me.Term_Stats_Panel.Controls.Add(Me.Label86, 0, 12)
        Me.Term_Stats_Panel.Controls.Add(Me.Label76, 0, 12)
        Me.Term_Stats_Panel.Controls.Add(Me.Label64, 0, 0)
        Me.Term_Stats_Panel.Controls.Add(Me.Label65, 1, 0)
        Me.Term_Stats_Panel.Controls.Add(Me.Label66, 2, 0)
        Me.Term_Stats_Panel.Controls.Add(Me.Label68, 0, 1)
        Me.Term_Stats_Panel.Controls.Add(Me.Label67, 0, 2)
        Me.Term_Stats_Panel.Controls.Add(Me.Label69, 0, 3)
        Me.Term_Stats_Panel.Controls.Add(Me.Label70, 0, 5)
        Me.Term_Stats_Panel.Controls.Add(Me.Label71, 0, 6)
        Me.Term_Stats_Panel.Controls.Add(Me.Label72, 0, 7)
        Me.Term_Stats_Panel.Controls.Add(Me.Label73, 0, 9)
        Me.Term_Stats_Panel.Controls.Add(Me.Label74, 0, 10)
        Me.Term_Stats_Panel.Controls.Add(Me.Label75, 0, 11)
        Me.Term_Stats_Panel.Controls.Add(Me.Label77, 1, 2)
        Me.Term_Stats_Panel.Controls.Add(Me.Label78, 1, 3)
        Me.Term_Stats_Panel.Controls.Add(Me.Label79, 2, 2)
        Me.Term_Stats_Panel.Controls.Add(Me.Label80, 2, 3)
        Me.Term_Stats_Panel.Controls.Add(Me.Label81, 1, 11)
        Me.Term_Stats_Panel.Controls.Add(Me.Label82, 1, 10)
        Me.Term_Stats_Panel.Controls.Add(Me.Label83, 2, 11)
        Me.Term_Stats_Panel.Controls.Add(Me.Label84, 2, 10)
        Me.Term_Stats_Panel.Controls.Add(Me.Label85, 2, 12)
        Me.Term_Stats_Panel.Location = New System.Drawing.Point(1120, 172)
        Me.Term_Stats_Panel.Name = "Term_Stats_Panel"
        Me.Term_Stats_Panel.RowCount = 13
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Term_Stats_Panel.Size = New System.Drawing.Size(771, 451)
        Me.Term_Stats_Panel.TabIndex = 6
        '
        'Label86
        '
        Me.Label86.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(442, 422)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(55, 24)
        Me.Label86.TabIndex = 44
        Me.Label86.Text = "2.915"
        '
        'Label76
        '
        Me.Label76.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(110, 422)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(70, 24)
        Me.Label76.TabIndex = 34
        Me.Label76.Text = "= GPA"
        '
        'Label64
        '
        Me.Label64.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(85, 15)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(120, 25)
        Me.Label64.TabIndex = 1
        Me.Label64.Text = "Description"
        '
        'Label65
        '
        Me.Label65.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(310, 15)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(169, 25)
        Me.Label65.TabIndex = 2
        Me.Label65.Text = "From Enrollment"
        '
        'Label66
        '
        Me.Label66.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(548, 15)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(175, 25)
        Me.Label66.TabIndex = 3
        Me.Label66.Text = "Cumulative Total"
        '
        'Label68
        '
        Me.Label68.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(52, 59)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(186, 24)
        Me.Label68.TabIndex = 25
        Me.Label68.Text = "Units Toward GPA:"
        '
        'Label67
        '
        Me.Label67.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(113, 92)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(63, 24)
        Me.Label67.TabIndex = 26
        Me.Label67.Text = "Taken"
        '
        'Label69
        '
        Me.Label69.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(109, 125)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(72, 24)
        Me.Label69.TabIndex = 27
        Me.Label69.Text = "Passed"
        '
        'Label70
        '
        Me.Label70.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(56, 191)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(178, 24)
        Me.Label70.TabIndex = 28
        Me.Label70.Text = "Units Not for GPA:"
        '
        'Label71
        '
        Me.Label71.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(113, 224)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(63, 24)
        Me.Label71.TabIndex = 29
        Me.Label71.Text = "Taken"
        '
        'Label72
        '
        Me.Label72.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.Location = New System.Drawing.Point(109, 257)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(72, 24)
        Me.Label72.TabIndex = 30
        Me.Label72.Text = "Passed"
        '
        'Label73
        '
        Me.Label73.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.Location = New System.Drawing.Point(72, 323)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(146, 24)
        Me.Label73.TabIndex = 31
        Me.Label73.Text = "GPA Calculation"
        '
        'Label74
        '
        Me.Label74.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.Location = New System.Drawing.Point(54, 356)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(182, 24)
        Me.Label74.TabIndex = 32
        Me.Label74.Text = "Total Grade Points"
        '
        'Label75
        '
        Me.Label75.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.Location = New System.Drawing.Point(21, 389)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(248, 24)
        Me.Label75.TabIndex = 33
        Me.Label75.Text = "/ Units taken Toward GPA"
        '
        'Label77
        '
        Me.Label77.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(432, 92)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(65, 24)
        Me.Label77.TabIndex = 35
        Me.Label77.Text = "10.000"
        '
        'Label78
        '
        Me.Label78.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(442, 125)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(55, 24)
        Me.Label78.TabIndex = 36
        Me.Label78.Text = "9.000"
        '
        'Label79
        '
        Me.Label79.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(702, 92)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(65, 24)
        Me.Label79.TabIndex = 37
        Me.Label79.Text = "10.000"
        '
        'Label80
        '
        Me.Label80.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(712, 125)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(55, 24)
        Me.Label80.TabIndex = 38
        Me.Label80.Text = "9.000"
        '
        'Label81
        '
        Me.Label81.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.Location = New System.Drawing.Point(432, 389)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(65, 24)
        Me.Label81.TabIndex = 39
        Me.Label81.Text = "10.000"
        '
        'Label82
        '
        Me.Label82.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(432, 356)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(65, 24)
        Me.Label82.TabIndex = 40
        Me.Label82.Text = "10.000"
        '
        'Label83
        '
        Me.Label83.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(702, 389)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(65, 24)
        Me.Label83.TabIndex = 41
        Me.Label83.Text = "10.000"
        '
        'Label84
        '
        Me.Label84.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.Location = New System.Drawing.Point(712, 356)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(55, 24)
        Me.Label84.TabIndex = 42
        Me.Label84.Text = "29.15"
        '
        'Label85
        '
        Me.Label85.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.Location = New System.Drawing.Point(712, 422)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(55, 24)
        Me.Label85.TabIndex = 43
        Me.Label85.Text = "2.915"
        '
        'Term_Stats_Button
        '
        Me.Term_Stats_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Term_Stats_Button.Location = New System.Drawing.Point(1110, 117)
        Me.Term_Stats_Button.Name = "Term_Stats_Button"
        Me.Term_Stats_Button.Size = New System.Drawing.Size(781, 35)
        Me.Term_Stats_Button.TabIndex = 7
        Me.Term_Stats_Button.Text = "Term Statistics"
        Me.Term_Stats_Button.UseVisualStyleBackColor = True
        '
        'AcademicStanding
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1914, 1045)
        Me.Controls.Add(Me.Term_Stats_Button)
        Me.Controls.Add(Me.Term_Stats_Panel)
        Me.Controls.Add(Me.Grades_15_Panel)
        Me.Controls.Add(Me.Grades_15_Button)
        Me.Controls.Add(Me.StandingLabel)
        Me.Controls.Add(Me.Title_Label)
        Me.Name = "AcademicStanding"
        Me.Text = "AcademicStanding"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Grades_15_Panel.ResumeLayout(False)
        Me.Grades_15_Panel.PerformLayout()
        Me.Term_Stats_Panel.ResumeLayout(False)
        Me.Term_Stats_Panel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Title_Label As Label
    Friend WithEvents StandingLabel As Label
    Friend WithEvents Grades_15_Button As Button
    Friend WithEvents Grades_15_Panel As TableLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Term_Stats_Panel As TableLayoutPanel
    Friend WithEvents Term_Stats_Button As Button
    Friend WithEvents Label64 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents Label87 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents Label89 As Label
End Class
