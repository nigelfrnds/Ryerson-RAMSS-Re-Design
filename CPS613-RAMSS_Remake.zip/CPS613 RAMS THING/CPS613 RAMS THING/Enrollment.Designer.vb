﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Enrollment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Enrollment))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Year1Label = New System.Windows.Forms.Label()
        Me.Year2Label = New System.Windows.Forms.Label()
        Me.Year1Panel = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Year2Panel = New System.Windows.Forms.Panel()
        Me.Y2S2AddButton = New System.Windows.Forms.Button()
        Me.Y2S1AddButton = New System.Windows.Forms.Button()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Y2BigPanel = New System.Windows.Forms.Panel()
        Me.Year2CloseButton = New System.Windows.Forms.Button()
        Me.Year2OpenButton = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PassedPictureBox = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Year3Label = New System.Windows.Forms.Label()
        Me.Year4Label = New System.Windows.Forms.Label()
        Me.Year3BigPanel = New System.Windows.Forms.Panel()
        Me.Year3CloseButton = New System.Windows.Forms.Button()
        Me.Year3OpenButton = New System.Windows.Forms.Button()
        Me.Year3Panel = New System.Windows.Forms.Panel()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.MinorsButton = New System.Windows.Forms.Button()
        Me.Year4BigPanel = New System.Windows.Forms.Panel()
        Me.Year4CloseButton = New System.Windows.Forms.Button()
        Me.Year4OpenButton = New System.Windows.Forms.Button()
        Me.Year4Panel = New System.Windows.Forms.Panel()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Year1CloseButton = New System.Windows.Forms.Button()
        Me.Year1OpenButton = New System.Windows.Forms.Button()
        Me.CPS209CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS109CO = New CPS613_RAMS_THING.CourseObject()
        Me.MTH207CO = New CPS613_RAMS_THING.CourseObject()
        Me.PCS110CO = New CPS613_RAMS_THING.CourseObject()
        Me.LL1CO = New CPS613_RAMS_THING.CourseObject()
        Me.LL2CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS412CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS213CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS310CO = New CPS613_RAMS_THING.CourseObject()
        Me.MTH110CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y2S26thCO = New CPS613_RAMS_THING.CourseObject()
        Me.Y2S16thCO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS506CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS305CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS420CO = New CPS613_RAMS_THING.CourseObject()
        Me.CMN300CO = New CPS613_RAMS_THING.CourseObject()
        Me.OE1CO = New CPS613_RAMS_THING.CourseObject()
        Me.OE2CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS406CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS393CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS590CO = New CPS613_RAMS_THING.CourseObject()
        Me.MTH108CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS616CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS510CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y3S2PR1CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS721CO = New CPS613_RAMS_THING.CourseObject()
        Me.LL3CO = New CPS613_RAMS_THING.CourseObject()
        Me.UL1CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y3S2PR2CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS633CO = New CPS613_RAMS_THING.CourseObject()
        Me.CPS706CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y3S1PRCO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S2PR3CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S1PR3CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S2PR1CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S1PR2CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S1ULCO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S2ULCO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S2PR2CO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S1OLCO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S2OLCO = New CPS613_RAMS_THING.CourseObject()
        Me.Y4S1PR1CO = New CPS613_RAMS_THING.CourseObject()
        Me.Year1Panel.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Year2Panel.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Y2BigPanel.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PassedPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Year3BigPanel.SuspendLayout()
        Me.Year3Panel.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Year4BigPanel.SuspendLayout()
        Me.Year4Panel.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(825, 6)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(253, 31)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Computer Science"
        '
        'Year1Label
        '
        Me.Year1Label.AutoSize = True
        Me.Year1Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year1Label.Location = New System.Drawing.Point(101, 36)
        Me.Year1Label.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Year1Label.Name = "Year1Label"
        Me.Year1Label.Size = New System.Drawing.Size(117, 29)
        Me.Year1Label.TabIndex = 5
        Me.Year1Label.Text = "First Year"
        '
        'Year2Label
        '
        Me.Year2Label.AutoSize = True
        Me.Year2Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year2Label.Location = New System.Drawing.Point(93, 6)
        Me.Year2Label.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Year2Label.Name = "Year2Label"
        Me.Year2Label.Size = New System.Drawing.Size(153, 29)
        Me.Year2Label.TabIndex = 8
        Me.Year2Label.Text = "Second Year"
        '
        'Year1Panel
        '
        Me.Year1Panel.BackColor = System.Drawing.SystemColors.Window
        Me.Year1Panel.Controls.Add(Me.PictureBox2)
        Me.Year1Panel.Controls.Add(Me.PictureBox1)
        Me.Year1Panel.Controls.Add(Me.CPS209CO)
        Me.Year1Panel.Controls.Add(Me.CPS109CO)
        Me.Year1Panel.Controls.Add(Me.MTH207CO)
        Me.Year1Panel.Controls.Add(Me.PCS110CO)
        Me.Year1Panel.Controls.Add(Me.LL1CO)
        Me.Year1Panel.Controls.Add(Me.LL2CO)
        Me.Year1Panel.Controls.Add(Me.CPS412CO)
        Me.Year1Panel.Controls.Add(Me.CPS213CO)
        Me.Year1Panel.Controls.Add(Me.CPS310CO)
        Me.Year1Panel.Controls.Add(Me.MTH110CO)
        Me.Year1Panel.Location = New System.Drawing.Point(23, 65)
        Me.Year1Panel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Year1Panel.Name = "Year1Panel"
        Me.Year1Panel.Size = New System.Drawing.Size(1267, 200)
        Me.Year1Panel.TabIndex = 10
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(2, 100)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(39, 98)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 23
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(4, 4)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(37, 92)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'Year2Panel
        '
        Me.Year2Panel.BackColor = System.Drawing.SystemColors.Window
        Me.Year2Panel.Controls.Add(Me.Y2S26thCO)
        Me.Year2Panel.Controls.Add(Me.Y2S16thCO)
        Me.Year2Panel.Controls.Add(Me.Y2S2AddButton)
        Me.Year2Panel.Controls.Add(Me.Y2S1AddButton)
        Me.Year2Panel.Controls.Add(Me.PictureBox3)
        Me.Year2Panel.Controls.Add(Me.PictureBox4)
        Me.Year2Panel.Controls.Add(Me.CPS506CO)
        Me.Year2Panel.Controls.Add(Me.CPS305CO)
        Me.Year2Panel.Controls.Add(Me.CPS420CO)
        Me.Year2Panel.Controls.Add(Me.CMN300CO)
        Me.Year2Panel.Controls.Add(Me.OE1CO)
        Me.Year2Panel.Controls.Add(Me.OE2CO)
        Me.Year2Panel.Controls.Add(Me.CPS406CO)
        Me.Year2Panel.Controls.Add(Me.CPS393CO)
        Me.Year2Panel.Controls.Add(Me.CPS590CO)
        Me.Year2Panel.Controls.Add(Me.MTH108CO)
        Me.Year2Panel.Location = New System.Drawing.Point(15, 35)
        Me.Year2Panel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Year2Panel.Name = "Year2Panel"
        Me.Year2Panel.Size = New System.Drawing.Size(1521, 202)
        Me.Year2Panel.TabIndex = 12
        '
        'Y2S2AddButton
        '
        Me.Y2S2AddButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Y2S2AddButton.Location = New System.Drawing.Point(1283, 122)
        Me.Y2S2AddButton.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Y2S2AddButton.Name = "Y2S2AddButton"
        Me.Y2S2AddButton.Size = New System.Drawing.Size(50, 47)
        Me.Y2S2AddButton.TabIndex = 27
        Me.Y2S2AddButton.Text = "+"
        Me.Y2S2AddButton.UseVisualStyleBackColor = True
        '
        'Y2S1AddButton
        '
        Me.Y2S1AddButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Y2S1AddButton.Location = New System.Drawing.Point(1283, 29)
        Me.Y2S1AddButton.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Y2S1AddButton.Name = "Y2S1AddButton"
        Me.Y2S1AddButton.Size = New System.Drawing.Size(50, 47)
        Me.Y2S1AddButton.TabIndex = 26
        Me.Y2S1AddButton.Text = "+"
        Me.Y2S1AddButton.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(4, 102)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(37, 92)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 24
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(4, 2)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(37, 92)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 25
        Me.PictureBox4.TabStop = False
        '
        'Y2BigPanel
        '
        Me.Y2BigPanel.BackColor = System.Drawing.SystemColors.Window
        Me.Y2BigPanel.Controls.Add(Me.Year2CloseButton)
        Me.Y2BigPanel.Controls.Add(Me.Year2OpenButton)
        Me.Y2BigPanel.Controls.Add(Me.Year2Label)
        Me.Y2BigPanel.Controls.Add(Me.Year2Panel)
        Me.Y2BigPanel.Location = New System.Drawing.Point(8, 266)
        Me.Y2BigPanel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Y2BigPanel.Name = "Y2BigPanel"
        Me.Y2BigPanel.Size = New System.Drawing.Size(1545, 238)
        Me.Y2BigPanel.TabIndex = 21
        '
        'Year2CloseButton
        '
        Me.Year2CloseButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year2CloseButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.open_button
        Me.Year2CloseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year2CloseButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year2CloseButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year2CloseButton.Location = New System.Drawing.Point(60, 8)
        Me.Year2CloseButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year2CloseButton.Name = "Year2CloseButton"
        Me.Year2CloseButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year2CloseButton.Size = New System.Drawing.Size(31, 25)
        Me.Year2CloseButton.TabIndex = 16
        Me.Year2CloseButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year2CloseButton.UseVisualStyleBackColor = False
        '
        'Year2OpenButton
        '
        Me.Year2OpenButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year2OpenButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.collapse_arrow16001
        Me.Year2OpenButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year2OpenButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year2OpenButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year2OpenButton.Location = New System.Drawing.Point(60, 8)
        Me.Year2OpenButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year2OpenButton.Name = "Year2OpenButton"
        Me.Year2OpenButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year2OpenButton.Size = New System.Drawing.Size(31, 25)
        Me.Year2OpenButton.TabIndex = 14
        Me.Year2OpenButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year2OpenButton.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(60, 106)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 20)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Enrolled"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(60, 70)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 20)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Failed"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(60, 35)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 20)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Passed"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(60, 176)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 20)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Unavailble"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(60, 142)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 20)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Open"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, -1)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(108, 29)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Legend:"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.PassedPictureBox)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.PictureBox8)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.PictureBox7)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.PictureBox6)
        Me.Panel1.Controls.Add(Me.PictureBox5)
        Me.Panel1.Location = New System.Drawing.Point(1557, 142)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(157, 213)
        Me.Panel1.TabIndex = 33
        '
        'PassedPictureBox
        '
        Me.PassedPictureBox.BackColor = System.Drawing.Color.LimeGreen
        Me.PassedPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PassedPictureBox.Location = New System.Drawing.Point(2, 29)
        Me.PassedPictureBox.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PassedPictureBox.Name = "PassedPictureBox"
        Me.PassedPictureBox.Size = New System.Drawing.Size(32, 27)
        Me.PassedPictureBox.TabIndex = 22
        Me.PassedPictureBox.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.DarkGray
        Me.PictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox8.Location = New System.Drawing.Point(2, 172)
        Me.PictureBox8.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(32, 27)
        Me.PictureBox8.TabIndex = 28
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.SkyBlue
        Me.PictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox7.Location = New System.Drawing.Point(2, 136)
        Me.PictureBox7.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(32, 27)
        Me.PictureBox7.TabIndex = 29
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.IndianRed
        Me.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox6.Location = New System.Drawing.Point(2, 65)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(32, 27)
        Me.PictureBox6.TabIndex = 23
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Gold
        Me.PictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox5.Location = New System.Drawing.Point(2, 100)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(32, 27)
        Me.PictureBox5.TabIndex = 26
        Me.PictureBox5.TabStop = False
        '
        'Year3Label
        '
        Me.Year3Label.AutoSize = True
        Me.Year3Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year3Label.Location = New System.Drawing.Point(93, 8)
        Me.Year3Label.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Year3Label.Name = "Year3Label"
        Me.Year3Label.Size = New System.Drawing.Size(127, 29)
        Me.Year3Label.TabIndex = 22
        Me.Year3Label.Text = "Third Year"
        '
        'Year4Label
        '
        Me.Year4Label.AutoSize = True
        Me.Year4Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year4Label.Location = New System.Drawing.Point(93, 6)
        Me.Year4Label.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Year4Label.Name = "Year4Label"
        Me.Year4Label.Size = New System.Drawing.Size(139, 29)
        Me.Year4Label.TabIndex = 22
        Me.Year4Label.Text = "Fourth Year"
        '
        'Year3BigPanel
        '
        Me.Year3BigPanel.BackColor = System.Drawing.SystemColors.Window
        Me.Year3BigPanel.Controls.Add(Me.Year3CloseButton)
        Me.Year3BigPanel.Controls.Add(Me.Year3OpenButton)
        Me.Year3BigPanel.Controls.Add(Me.Year3Label)
        Me.Year3BigPanel.Controls.Add(Me.Year3Panel)
        Me.Year3BigPanel.Location = New System.Drawing.Point(8, 508)
        Me.Year3BigPanel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Year3BigPanel.Name = "Year3BigPanel"
        Me.Year3BigPanel.Size = New System.Drawing.Size(1310, 229)
        Me.Year3BigPanel.TabIndex = 22
        '
        'Year3CloseButton
        '
        Me.Year3CloseButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year3CloseButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.open_button
        Me.Year3CloseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year3CloseButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year3CloseButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year3CloseButton.Location = New System.Drawing.Point(60, 8)
        Me.Year3CloseButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year3CloseButton.Name = "Year3CloseButton"
        Me.Year3CloseButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year3CloseButton.Size = New System.Drawing.Size(31, 25)
        Me.Year3CloseButton.TabIndex = 16
        Me.Year3CloseButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year3CloseButton.UseVisualStyleBackColor = False
        '
        'Year3OpenButton
        '
        Me.Year3OpenButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year3OpenButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.collapse_arrow16001
        Me.Year3OpenButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year3OpenButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year3OpenButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year3OpenButton.Location = New System.Drawing.Point(60, 8)
        Me.Year3OpenButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year3OpenButton.Name = "Year3OpenButton"
        Me.Year3OpenButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year3OpenButton.Size = New System.Drawing.Size(31, 25)
        Me.Year3OpenButton.TabIndex = 14
        Me.Year3OpenButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year3OpenButton.UseVisualStyleBackColor = False
        '
        'Year3Panel
        '
        Me.Year3Panel.BackColor = System.Drawing.SystemColors.Window
        Me.Year3Panel.Controls.Add(Me.PictureBox9)
        Me.Year3Panel.Controls.Add(Me.PictureBox10)
        Me.Year3Panel.Controls.Add(Me.CPS616CO)
        Me.Year3Panel.Controls.Add(Me.CPS510CO)
        Me.Year3Panel.Controls.Add(Me.Y3S2PR1CO)
        Me.Year3Panel.Controls.Add(Me.CPS721CO)
        Me.Year3Panel.Controls.Add(Me.LL3CO)
        Me.Year3Panel.Controls.Add(Me.UL1CO)
        Me.Year3Panel.Controls.Add(Me.Y3S2PR2CO)
        Me.Year3Panel.Controls.Add(Me.CPS633CO)
        Me.Year3Panel.Controls.Add(Me.CPS706CO)
        Me.Year3Panel.Controls.Add(Me.Y3S1PRCO)
        Me.Year3Panel.Location = New System.Drawing.Point(15, 35)
        Me.Year3Panel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Year3Panel.Name = "Year3Panel"
        Me.Year3Panel.Size = New System.Drawing.Size(1279, 202)
        Me.Year3Panel.TabIndex = 12
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.CPS613_RAMS_THING.My.Resources.Resources.winter2018label
        Me.PictureBox9.Location = New System.Drawing.Point(4, 102)
        Me.PictureBox9.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(37, 92)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 24
        Me.PictureBox9.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.CPS613_RAMS_THING.My.Resources.Resources.fall2017label
        Me.PictureBox10.Location = New System.Drawing.Point(4, 2)
        Me.PictureBox10.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(37, 92)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 25
        Me.PictureBox10.TabStop = False
        '
        'MinorsButton
        '
        Me.MinorsButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MinorsButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MinorsButton.Location = New System.Drawing.Point(1482, 65)
        Me.MinorsButton.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MinorsButton.Name = "MinorsButton"
        Me.MinorsButton.Size = New System.Drawing.Size(231, 67)
        Me.MinorsButton.TabIndex = 34
        Me.MinorsButton.Text = "Manage Minors"
        Me.MinorsButton.UseVisualStyleBackColor = True
        '
        'Year4BigPanel
        '
        Me.Year4BigPanel.BackColor = System.Drawing.SystemColors.Window
        Me.Year4BigPanel.Controls.Add(Me.Year4CloseButton)
        Me.Year4BigPanel.Controls.Add(Me.Year4OpenButton)
        Me.Year4BigPanel.Controls.Add(Me.Year4Label)
        Me.Year4BigPanel.Controls.Add(Me.Year4Panel)
        Me.Year4BigPanel.Location = New System.Drawing.Point(8, 743)
        Me.Year4BigPanel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Year4BigPanel.Name = "Year4BigPanel"
        Me.Year4BigPanel.Size = New System.Drawing.Size(1310, 250)
        Me.Year4BigPanel.TabIndex = 23
        '
        'Year4CloseButton
        '
        Me.Year4CloseButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year4CloseButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.open_button
        Me.Year4CloseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year4CloseButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year4CloseButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year4CloseButton.Location = New System.Drawing.Point(60, 8)
        Me.Year4CloseButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year4CloseButton.Name = "Year4CloseButton"
        Me.Year4CloseButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year4CloseButton.Size = New System.Drawing.Size(31, 25)
        Me.Year4CloseButton.TabIndex = 16
        Me.Year4CloseButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year4CloseButton.UseVisualStyleBackColor = False
        '
        'Year4OpenButton
        '
        Me.Year4OpenButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year4OpenButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.collapse_arrow16001
        Me.Year4OpenButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year4OpenButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year4OpenButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year4OpenButton.Location = New System.Drawing.Point(60, 8)
        Me.Year4OpenButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year4OpenButton.Name = "Year4OpenButton"
        Me.Year4OpenButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year4OpenButton.Size = New System.Drawing.Size(31, 25)
        Me.Year4OpenButton.TabIndex = 14
        Me.Year4OpenButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year4OpenButton.UseVisualStyleBackColor = False
        '
        'Year4Panel
        '
        Me.Year4Panel.BackColor = System.Drawing.SystemColors.Window
        Me.Year4Panel.Controls.Add(Me.PictureBox11)
        Me.Year4Panel.Controls.Add(Me.PictureBox12)
        Me.Year4Panel.Controls.Add(Me.Y4S2PR3CO)
        Me.Year4Panel.Controls.Add(Me.Y4S1PR3CO)
        Me.Year4Panel.Controls.Add(Me.Y4S2PR1CO)
        Me.Year4Panel.Controls.Add(Me.Y4S1PR2CO)
        Me.Year4Panel.Controls.Add(Me.Y4S1ULCO)
        Me.Year4Panel.Controls.Add(Me.Y4S2ULCO)
        Me.Year4Panel.Controls.Add(Me.Y4S2PR2CO)
        Me.Year4Panel.Controls.Add(Me.Y4S1OLCO)
        Me.Year4Panel.Controls.Add(Me.Y4S2OLCO)
        Me.Year4Panel.Controls.Add(Me.Y4S1PR1CO)
        Me.Year4Panel.Location = New System.Drawing.Point(15, 35)
        Me.Year4Panel.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Year4Panel.Name = "Year4Panel"
        Me.Year4Panel.Size = New System.Drawing.Size(1279, 202)
        Me.Year4Panel.TabIndex = 12
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = Global.CPS613_RAMS_THING.My.Resources.Resources.winter2019label
        Me.PictureBox11.Location = New System.Drawing.Point(4, 102)
        Me.PictureBox11.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(37, 92)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox11.TabIndex = 24
        Me.PictureBox11.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.Image = Global.CPS613_RAMS_THING.My.Resources.Resources.fall2018label
        Me.PictureBox12.Location = New System.Drawing.Point(4, 2)
        Me.PictureBox12.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(37, 92)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox12.TabIndex = 25
        Me.PictureBox12.TabStop = False
        '
        'Year1CloseButton
        '
        Me.Year1CloseButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year1CloseButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.open_button
        Me.Year1CloseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year1CloseButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year1CloseButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year1CloseButton.Location = New System.Drawing.Point(68, 40)
        Me.Year1CloseButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year1CloseButton.Name = "Year1CloseButton"
        Me.Year1CloseButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year1CloseButton.Size = New System.Drawing.Size(31, 23)
        Me.Year1CloseButton.TabIndex = 15
        Me.Year1CloseButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year1CloseButton.UseVisualStyleBackColor = False
        '
        'Year1OpenButton
        '
        Me.Year1OpenButton.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Year1OpenButton.BackgroundImage = Global.CPS613_RAMS_THING.My.Resources.Resources.collapse_arrow16001
        Me.Year1OpenButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Year1OpenButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Year1OpenButton.ForeColor = System.Drawing.Color.DimGray
        Me.Year1OpenButton.Location = New System.Drawing.Point(68, 40)
        Me.Year1OpenButton.Margin = New System.Windows.Forms.Padding(0)
        Me.Year1OpenButton.Name = "Year1OpenButton"
        Me.Year1OpenButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Year1OpenButton.Size = New System.Drawing.Size(31, 23)
        Me.Year1OpenButton.TabIndex = 13
        Me.Year1OpenButton.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Year1OpenButton.UseVisualStyleBackColor = False
        '
        'CPS209CO
        '
        Me.CPS209CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS209CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS209CO.Course_Code = "CPS209"
        Me.CPS209CO.Course_Grade = 0R
        Me.CPS209CO.Course_Name = "Computer Science II"
        Me.CPS209CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS209CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS209CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS209CO.Location = New System.Drawing.Point(538, 104)
        Me.CPS209CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS209CO.Name = "CPS209CO"
        Me.CPS209CO.Pre_Requisite = "CPS109"
        Me.CPS209CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS209CO.TabIndex = 18
        '
        'CPS109CO
        '
        Me.CPS109CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS109CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS109CO.Course_Code = "CPS109"
        Me.CPS109CO.Course_Grade = 0R
        Me.CPS109CO.Course_Name = "Computer Science I"
        Me.CPS109CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS109CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS109CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS109CO.Location = New System.Drawing.Point(538, 4)
        Me.CPS109CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS109CO.Name = "CPS109CO"
        Me.CPS109CO.Pre_Requisite = Nothing
        Me.CPS109CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS109CO.TabIndex = 17
        '
        'MTH207CO
        '
        Me.MTH207CO.BackColor = System.Drawing.Color.SkyBlue
        Me.MTH207CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.MTH207CO.Course_Code = "MTH207"
        Me.MTH207CO.Course_Grade = 0R
        Me.MTH207CO.Course_Name = "Calc and Comp Methods I"
        Me.MTH207CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.MTH207CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.MTH207CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.MTH207CO.Location = New System.Drawing.Point(43, 104)
        Me.MTH207CO.Margin = New System.Windows.Forms.Padding(4)
        Me.MTH207CO.Name = "MTH207CO"
        Me.MTH207CO.Pre_Requisite = Nothing
        Me.MTH207CO.Size = New System.Drawing.Size(227, 93)
        Me.MTH207CO.TabIndex = 16
        '
        'PCS110CO
        '
        Me.PCS110CO.BackColor = System.Drawing.Color.SkyBlue
        Me.PCS110CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PCS110CO.Course_Code = "PCS110"
        Me.PCS110CO.Course_Grade = 0R
        Me.PCS110CO.Course_Name = "Physics"
        Me.PCS110CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.PCS110CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.PCS110CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.PCS110CO.Location = New System.Drawing.Point(291, 4)
        Me.PCS110CO.Margin = New System.Windows.Forms.Padding(4)
        Me.PCS110CO.Name = "PCS110CO"
        Me.PCS110CO.Pre_Requisite = Nothing
        Me.PCS110CO.Size = New System.Drawing.Size(227, 93)
        Me.PCS110CO.TabIndex = 15
        '
        'LL1CO
        '
        Me.LL1CO.BackColor = System.Drawing.Color.SkyBlue
        Me.LL1CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LL1CO.Course_Code = "PSY105"
        Me.LL1CO.Course_Grade = 0R
        Me.LL1CO.Course_Name = "Psy of Gender"
        Me.LL1CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.LL1CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Open_Elective
        Me.LL1CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.LL1CO.Location = New System.Drawing.Point(1033, 1)
        Me.LL1CO.Margin = New System.Windows.Forms.Padding(4)
        Me.LL1CO.Name = "LL1CO"
        Me.LL1CO.Pre_Requisite = Nothing
        Me.LL1CO.Size = New System.Drawing.Size(227, 93)
        Me.LL1CO.TabIndex = 14
        '
        'LL2CO
        '
        Me.LL2CO.BackColor = System.Drawing.Color.SkyBlue
        Me.LL2CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LL2CO.Course_Code = "PSY304"
        Me.LL2CO.Course_Grade = 0R
        Me.LL2CO.Course_Name = "Persp. in Psy"
        Me.LL2CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.LL2CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Open_Elective
        Me.LL2CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.LL2CO.Location = New System.Drawing.Point(1033, 104)
        Me.LL2CO.Margin = New System.Windows.Forms.Padding(4)
        Me.LL2CO.Name = "LL2CO"
        Me.LL2CO.Pre_Requisite = Nothing
        Me.LL2CO.Size = New System.Drawing.Size(227, 93)
        Me.LL2CO.TabIndex = 13
        '
        'CPS412CO
        '
        Me.CPS412CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS412CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS412CO.Course_Code = "CPS412"
        Me.CPS412CO.Course_Grade = 0R
        Me.CPS412CO.Course_Name = "Social Issues..."
        Me.CPS412CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS412CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS412CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS412CO.Location = New System.Drawing.Point(291, 104)
        Me.CPS412CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS412CO.Name = "CPS412CO"
        Me.CPS412CO.Pre_Requisite = Nothing
        Me.CPS412CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS412CO.TabIndex = 12
        '
        'CPS213CO
        '
        Me.CPS213CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS213CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS213CO.Course_Code = "CPS213"
        Me.CPS213CO.Course_Grade = 0R
        Me.CPS213CO.Course_Name = "Comp Org I"
        Me.CPS213CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS213CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS213CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS213CO.Location = New System.Drawing.Point(785, 4)
        Me.CPS213CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS213CO.Name = "CPS213CO"
        Me.CPS213CO.Pre_Requisite = Nothing
        Me.CPS213CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS213CO.TabIndex = 11
        '
        'CPS310CO
        '
        Me.CPS310CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS310CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS310CO.Course_Code = "CPS310"
        Me.CPS310CO.Course_Grade = 0R
        Me.CPS310CO.Course_Name = "Comp Org II"
        Me.CPS310CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS310CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS310CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS310CO.Location = New System.Drawing.Point(785, 104)
        Me.CPS310CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS310CO.Name = "CPS310CO"
        Me.CPS310CO.Pre_Requisite = "CPS213"
        Me.CPS310CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS310CO.TabIndex = 10
        '
        'MTH110CO
        '
        Me.MTH110CO.BackColor = System.Drawing.Color.SkyBlue
        Me.MTH110CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.MTH110CO.Course_Code = "MTH110"
        Me.MTH110CO.Course_Grade = 0R
        Me.MTH110CO.Course_Name = "Discrete Math I"
        Me.MTH110CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.MTH110CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.MTH110CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.MTH110CO.Location = New System.Drawing.Point(43, 4)
        Me.MTH110CO.Margin = New System.Windows.Forms.Padding(4)
        Me.MTH110CO.Name = "MTH110CO"
        Me.MTH110CO.Pre_Requisite = Nothing
        Me.MTH110CO.Size = New System.Drawing.Size(227, 93)
        Me.MTH110CO.TabIndex = 9
        '
        'Y2S26thCO
        '
        Me.Y2S26thCO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y2S26thCO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y2S26thCO.Course_Code = "Course Code"
        Me.Y2S26thCO.Course_Grade = 0R
        Me.Y2S26thCO.Course_Name = "Course Name"
        Me.Y2S26thCO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y2S26thCO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.Y2S26thCO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y2S26thCO.Location = New System.Drawing.Point(1283, 102)
        Me.Y2S26thCO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y2S26thCO.Name = "Y2S26thCO"
        Me.Y2S26thCO.Pre_Requisite = Nothing
        Me.Y2S26thCO.Size = New System.Drawing.Size(227, 93)
        Me.Y2S26thCO.TabIndex = 29
        Me.Y2S26thCO.Visible = False
        '
        'Y2S16thCO
        '
        Me.Y2S16thCO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y2S16thCO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y2S16thCO.Course_Code = "Course Code"
        Me.Y2S16thCO.Course_Grade = 0R
        Me.Y2S16thCO.Course_Name = "Course Name"
        Me.Y2S16thCO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y2S16thCO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.Y2S16thCO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y2S16thCO.Location = New System.Drawing.Point(1283, 4)
        Me.Y2S16thCO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y2S16thCO.Name = "Y2S16thCO"
        Me.Y2S16thCO.Pre_Requisite = Nothing
        Me.Y2S16thCO.Size = New System.Drawing.Size(227, 93)
        Me.Y2S16thCO.TabIndex = 28
        Me.Y2S16thCO.Visible = False
        '
        'CPS506CO
        '
        Me.CPS506CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS506CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS506CO.Course_Code = "CPS506"
        Me.CPS506CO.Course_Grade = 0R
        Me.CPS506CO.Course_Name = "Comparative Prog"
        Me.CPS506CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS506CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS506CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS506CO.Location = New System.Drawing.Point(538, 102)
        Me.CPS506CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS506CO.Name = "CPS506CO"
        Me.CPS506CO.Pre_Requisite = "CPS209"
        Me.CPS506CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS506CO.TabIndex = 18
        '
        'CPS305CO
        '
        Me.CPS305CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS305CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS305CO.Course_Code = "CPS305"
        Me.CPS305CO.Course_Grade = 0R
        Me.CPS305CO.Course_Name = "Data Structures"
        Me.CPS305CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS305CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS305CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS305CO.Location = New System.Drawing.Point(538, 2)
        Me.CPS305CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS305CO.Name = "CPS305CO"
        Me.CPS305CO.Pre_Requisite = "CPS209"
        Me.CPS305CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS305CO.TabIndex = 17
        '
        'CPS420CO
        '
        Me.CPS420CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS420CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS420CO.Course_Code = "CPS420"
        Me.CPS420CO.Course_Grade = 0R
        Me.CPS420CO.Course_Name = "Discrete Structures"
        Me.CPS420CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS420CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS420CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS420CO.Location = New System.Drawing.Point(43, 102)
        Me.CPS420CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS420CO.Name = "CPS420CO"
        Me.CPS420CO.Pre_Requisite = "MTH110"
        Me.CPS420CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS420CO.TabIndex = 16
        '
        'CMN300CO
        '
        Me.CMN300CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CMN300CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CMN300CO.Course_Code = "CMN300"
        Me.CMN300CO.Course_Grade = 0R
        Me.CMN300CO.Course_Name = "Cmn in Comp Ind"
        Me.CMN300CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CMN300CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CMN300CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CMN300CO.Location = New System.Drawing.Point(291, 2)
        Me.CMN300CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CMN300CO.Name = "CMN300CO"
        Me.CMN300CO.Pre_Requisite = Nothing
        Me.CMN300CO.Size = New System.Drawing.Size(227, 93)
        Me.CMN300CO.TabIndex = 15
        '
        'OE1CO
        '
        Me.OE1CO.BackColor = System.Drawing.Color.SkyBlue
        Me.OE1CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.OE1CO.Course_Code = "Course Code"
        Me.OE1CO.Course_Grade = 0R
        Me.OE1CO.Course_Name = "Course Name"
        Me.OE1CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.OE1CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Open_Elective
        Me.OE1CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.OE1CO.Location = New System.Drawing.Point(1033, 4)
        Me.OE1CO.Margin = New System.Windows.Forms.Padding(4)
        Me.OE1CO.Name = "OE1CO"
        Me.OE1CO.Pre_Requisite = Nothing
        Me.OE1CO.Size = New System.Drawing.Size(227, 93)
        Me.OE1CO.TabIndex = 14
        '
        'OE2CO
        '
        Me.OE2CO.BackColor = System.Drawing.Color.SkyBlue
        Me.OE2CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.OE2CO.Course_Code = "Course Code"
        Me.OE2CO.Course_Grade = 0R
        Me.OE2CO.Course_Name = "Course Name"
        Me.OE2CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.OE2CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Open_Elective
        Me.OE2CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.OE2CO.Location = New System.Drawing.Point(1033, 102)
        Me.OE2CO.Margin = New System.Windows.Forms.Padding(4)
        Me.OE2CO.Name = "OE2CO"
        Me.OE2CO.Pre_Requisite = Nothing
        Me.OE2CO.Size = New System.Drawing.Size(227, 93)
        Me.OE2CO.TabIndex = 13
        '
        'CPS406CO
        '
        Me.CPS406CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS406CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS406CO.Course_Code = "CPS406"
        Me.CPS406CO.Course_Grade = 0R
        Me.CPS406CO.Course_Name = "Software Eng"
        Me.CPS406CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS406CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS406CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS406CO.Location = New System.Drawing.Point(291, 102)
        Me.CPS406CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS406CO.Name = "CPS406CO"
        Me.CPS406CO.Pre_Requisite = "CPS209"
        Me.CPS406CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS406CO.TabIndex = 12
        '
        'CPS393CO
        '
        Me.CPS393CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS393CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS393CO.Course_Code = "CPS393"
        Me.CPS393CO.Course_Grade = 0R
        Me.CPS393CO.Course_Name = "C and UNIX"
        Me.CPS393CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS393CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS393CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS393CO.Location = New System.Drawing.Point(785, 2)
        Me.CPS393CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS393CO.Name = "CPS393CO"
        Me.CPS393CO.Pre_Requisite = "CPS109"
        Me.CPS393CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS393CO.TabIndex = 11
        '
        'CPS590CO
        '
        Me.CPS590CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS590CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS590CO.Course_Code = "CPS590"
        Me.CPS590CO.Course_Grade = 0R
        Me.CPS590CO.Course_Name = "Op Systems I"
        Me.CPS590CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS590CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS590CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS590CO.Location = New System.Drawing.Point(785, 102)
        Me.CPS590CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS590CO.Name = "CPS590CO"
        Me.CPS590CO.Pre_Requisite = "CPS393, CPS305"
        Me.CPS590CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS590CO.TabIndex = 10
        '
        'MTH108CO
        '
        Me.MTH108CO.BackColor = System.Drawing.Color.SkyBlue
        Me.MTH108CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.MTH108CO.Course_Code = "MTH108"
        Me.MTH108CO.Course_Grade = 0R
        Me.MTH108CO.Course_Name = "Linear Algebra"
        Me.MTH108CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.MTH108CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.MTH108CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.MTH108CO.Location = New System.Drawing.Point(43, 2)
        Me.MTH108CO.Margin = New System.Windows.Forms.Padding(4)
        Me.MTH108CO.Name = "MTH108CO"
        Me.MTH108CO.Pre_Requisite = Nothing
        Me.MTH108CO.Size = New System.Drawing.Size(227, 93)
        Me.MTH108CO.TabIndex = 9
        '
        'CPS616CO
        '
        Me.CPS616CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS616CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS616CO.Course_Code = "CPS616"
        Me.CPS616CO.Course_Grade = 0R
        Me.CPS616CO.Course_Name = "Algorithms"
        Me.CPS616CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS616CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS616CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS616CO.Location = New System.Drawing.Point(538, 102)
        Me.CPS616CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS616CO.Name = "CPS616CO"
        Me.CPS616CO.Pre_Requisite = "CPS420, CPS305"
        Me.CPS616CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS616CO.TabIndex = 18
        '
        'CPS510CO
        '
        Me.CPS510CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS510CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS510CO.Course_Code = "CPS510"
        Me.CPS510CO.Course_Grade = 0R
        Me.CPS510CO.Course_Name = "Databases I"
        Me.CPS510CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS510CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS510CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS510CO.Location = New System.Drawing.Point(538, 2)
        Me.CPS510CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS510CO.Name = "CPS510CO"
        Me.CPS510CO.Pre_Requisite = "CPS305"
        Me.CPS510CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS510CO.TabIndex = 17
        '
        'Y3S2PR1CO
        '
        Me.Y3S2PR1CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y3S2PR1CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y3S2PR1CO.Course_Code = "Course Code"
        Me.Y3S2PR1CO.Course_Grade = 0R
        Me.Y3S2PR1CO.Course_Name = "Course Name"
        Me.Y3S2PR1CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y3S2PR1CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.Y3S2PR1CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y3S2PR1CO.Location = New System.Drawing.Point(43, 102)
        Me.Y3S2PR1CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y3S2PR1CO.Name = "Y3S2PR1CO"
        Me.Y3S2PR1CO.Pre_Requisite = Nothing
        Me.Y3S2PR1CO.Size = New System.Drawing.Size(227, 93)
        Me.Y3S2PR1CO.TabIndex = 16
        '
        'CPS721CO
        '
        Me.CPS721CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS721CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS721CO.Course_Code = "CPS721"
        Me.CPS721CO.Course_Grade = 0R
        Me.CPS721CO.Course_Name = "Artificial Intel"
        Me.CPS721CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS721CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS721CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS721CO.Location = New System.Drawing.Point(291, 2)
        Me.CPS721CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS721CO.Name = "CPS721CO"
        Me.CPS721CO.Pre_Requisite = "CPS420, CPS305"
        Me.CPS721CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS721CO.TabIndex = 15
        '
        'LL3CO
        '
        Me.LL3CO.BackColor = System.Drawing.Color.SkyBlue
        Me.LL3CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LL3CO.Course_Code = "Course Code"
        Me.LL3CO.Course_Grade = 0R
        Me.LL3CO.Course_Name = "Course Name"
        Me.LL3CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.LL3CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.LL3CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.LL3CO.Location = New System.Drawing.Point(1033, 4)
        Me.LL3CO.Margin = New System.Windows.Forms.Padding(4)
        Me.LL3CO.Name = "LL3CO"
        Me.LL3CO.Pre_Requisite = Nothing
        Me.LL3CO.Size = New System.Drawing.Size(227, 93)
        Me.LL3CO.TabIndex = 14
        '
        'UL1CO
        '
        Me.UL1CO.BackColor = System.Drawing.Color.SkyBlue
        Me.UL1CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UL1CO.Course_Code = "Course Code"
        Me.UL1CO.Course_Grade = 0R
        Me.UL1CO.Course_Name = "Course Name"
        Me.UL1CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.UL1CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.UL1CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.UL1CO.Location = New System.Drawing.Point(1033, 102)
        Me.UL1CO.Margin = New System.Windows.Forms.Padding(4)
        Me.UL1CO.Name = "UL1CO"
        Me.UL1CO.Pre_Requisite = Nothing
        Me.UL1CO.Size = New System.Drawing.Size(227, 93)
        Me.UL1CO.TabIndex = 13
        '
        'Y3S2PR2CO
        '
        Me.Y3S2PR2CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y3S2PR2CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y3S2PR2CO.Course_Code = "Course Code"
        Me.Y3S2PR2CO.Course_Grade = 0R
        Me.Y3S2PR2CO.Course_Name = "Course Name"
        Me.Y3S2PR2CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y3S2PR2CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.Y3S2PR2CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y3S2PR2CO.Location = New System.Drawing.Point(291, 102)
        Me.Y3S2PR2CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y3S2PR2CO.Name = "Y3S2PR2CO"
        Me.Y3S2PR2CO.Pre_Requisite = Nothing
        Me.Y3S2PR2CO.Size = New System.Drawing.Size(227, 93)
        Me.Y3S2PR2CO.TabIndex = 12
        '
        'CPS633CO
        '
        Me.CPS633CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS633CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS633CO.Course_Code = "CPS633"
        Me.CPS633CO.Course_Grade = 0R
        Me.CPS633CO.Course_Name = "Computer Security"
        Me.CPS633CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS633CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS633CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS633CO.Location = New System.Drawing.Point(785, 2)
        Me.CPS633CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS633CO.Name = "CPS633CO"
        Me.CPS633CO.Pre_Requisite = "CPS393"
        Me.CPS633CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS633CO.TabIndex = 11
        '
        'CPS706CO
        '
        Me.CPS706CO.BackColor = System.Drawing.Color.SkyBlue
        Me.CPS706CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CPS706CO.Course_Code = "CPS706"
        Me.CPS706CO.Course_Grade = 0R
        Me.CPS706CO.Course_Name = "Networks I"
        Me.CPS706CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.CPS706CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Mandatory
        Me.CPS706CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.CPS706CO.Location = New System.Drawing.Point(785, 102)
        Me.CPS706CO.Margin = New System.Windows.Forms.Padding(4)
        Me.CPS706CO.Name = "CPS706CO"
        Me.CPS706CO.Pre_Requisite = Nothing
        Me.CPS706CO.Size = New System.Drawing.Size(227, 93)
        Me.CPS706CO.TabIndex = 10
        '
        'Y3S1PRCO
        '
        Me.Y3S1PRCO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y3S1PRCO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y3S1PRCO.Course_Code = "Course Code"
        Me.Y3S1PRCO.Course_Grade = 0R
        Me.Y3S1PRCO.Course_Name = "Course Name"
        Me.Y3S1PRCO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y3S1PRCO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.Y3S1PRCO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y3S1PRCO.Location = New System.Drawing.Point(43, 2)
        Me.Y3S1PRCO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y3S1PRCO.Name = "Y3S1PRCO"
        Me.Y3S1PRCO.Pre_Requisite = Nothing
        Me.Y3S1PRCO.Size = New System.Drawing.Size(227, 93)
        Me.Y3S1PRCO.TabIndex = 9
        '
        'Y4S2PR3CO
        '
        Me.Y4S2PR3CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S2PR3CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S2PR3CO.Course_Code = "Professionally"
        Me.Y4S2PR3CO.Course_Grade = 0R
        Me.Y4S2PR3CO.Course_Name = "Related"
        Me.Y4S2PR3CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S2PR3CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Pro_Related
        Me.Y4S2PR3CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S2PR3CO.Location = New System.Drawing.Point(538, 102)
        Me.Y4S2PR3CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S2PR3CO.Name = "Y4S2PR3CO"
        Me.Y4S2PR3CO.Pre_Requisite = Nothing
        Me.Y4S2PR3CO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S2PR3CO.TabIndex = 18
        '
        'Y4S1PR3CO
        '
        Me.Y4S1PR3CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S1PR3CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S1PR3CO.Course_Code = "Professionally"
        Me.Y4S1PR3CO.Course_Grade = 0R
        Me.Y4S1PR3CO.Course_Name = "Related"
        Me.Y4S1PR3CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S1PR3CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Pro_Related
        Me.Y4S1PR3CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S1PR3CO.Location = New System.Drawing.Point(538, 2)
        Me.Y4S1PR3CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S1PR3CO.Name = "Y4S1PR3CO"
        Me.Y4S1PR3CO.Pre_Requisite = Nothing
        Me.Y4S1PR3CO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S1PR3CO.TabIndex = 17
        '
        'Y4S2PR1CO
        '
        Me.Y4S2PR1CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S2PR1CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S2PR1CO.Course_Code = "Professionally"
        Me.Y4S2PR1CO.Course_Grade = 0R
        Me.Y4S2PR1CO.Course_Name = "Related"
        Me.Y4S2PR1CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S2PR1CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Pro_Related
        Me.Y4S2PR1CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S2PR1CO.Location = New System.Drawing.Point(43, 102)
        Me.Y4S2PR1CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S2PR1CO.Name = "Y4S2PR1CO"
        Me.Y4S2PR1CO.Pre_Requisite = Nothing
        Me.Y4S2PR1CO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S2PR1CO.TabIndex = 16
        '
        'Y4S1PR2CO
        '
        Me.Y4S1PR2CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S1PR2CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S1PR2CO.Course_Code = "Professionally"
        Me.Y4S1PR2CO.Course_Grade = 0R
        Me.Y4S1PR2CO.Course_Name = "Related"
        Me.Y4S1PR2CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S1PR2CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Pro_Related
        Me.Y4S1PR2CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S1PR2CO.Location = New System.Drawing.Point(291, 2)
        Me.Y4S1PR2CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S1PR2CO.Name = "Y4S1PR2CO"
        Me.Y4S1PR2CO.Pre_Requisite = Nothing
        Me.Y4S1PR2CO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S1PR2CO.TabIndex = 15
        '
        'Y4S1ULCO
        '
        Me.Y4S1ULCO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S1ULCO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S1ULCO.Course_Code = "Upper"
        Me.Y4S1ULCO.Course_Grade = 0R
        Me.Y4S1ULCO.Course_Name = "Liberal"
        Me.Y4S1ULCO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S1ULCO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.Y4S1ULCO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S1ULCO.Location = New System.Drawing.Point(1033, 4)
        Me.Y4S1ULCO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S1ULCO.Name = "Y4S1ULCO"
        Me.Y4S1ULCO.Pre_Requisite = Nothing
        Me.Y4S1ULCO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S1ULCO.TabIndex = 14
        '
        'Y4S2ULCO
        '
        Me.Y4S2ULCO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S2ULCO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S2ULCO.Course_Code = "Upper"
        Me.Y4S2ULCO.Course_Grade = 0R
        Me.Y4S2ULCO.Course_Name = "Liberal"
        Me.Y4S2ULCO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S2ULCO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Liberal
        Me.Y4S2ULCO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S2ULCO.Location = New System.Drawing.Point(1033, 102)
        Me.Y4S2ULCO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S2ULCO.Name = "Y4S2ULCO"
        Me.Y4S2ULCO.Pre_Requisite = Nothing
        Me.Y4S2ULCO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S2ULCO.TabIndex = 13
        '
        'Y4S2PR2CO
        '
        Me.Y4S2PR2CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S2PR2CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S2PR2CO.Course_Code = "Professionally"
        Me.Y4S2PR2CO.Course_Grade = 0R
        Me.Y4S2PR2CO.Course_Name = "Related"
        Me.Y4S2PR2CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S2PR2CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Pro_Related
        Me.Y4S2PR2CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S2PR2CO.Location = New System.Drawing.Point(291, 102)
        Me.Y4S2PR2CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S2PR2CO.Name = "Y4S2PR2CO"
        Me.Y4S2PR2CO.Pre_Requisite = Nothing
        Me.Y4S2PR2CO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S2PR2CO.TabIndex = 12
        '
        'Y4S1OLCO
        '
        Me.Y4S1OLCO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S1OLCO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S1OLCO.Course_Code = "Open"
        Me.Y4S1OLCO.Course_Grade = 0R
        Me.Y4S1OLCO.Course_Name = "Elective"
        Me.Y4S1OLCO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S1OLCO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Open_Elective
        Me.Y4S1OLCO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S1OLCO.Location = New System.Drawing.Point(785, 2)
        Me.Y4S1OLCO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S1OLCO.Name = "Y4S1OLCO"
        Me.Y4S1OLCO.Pre_Requisite = Nothing
        Me.Y4S1OLCO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S1OLCO.TabIndex = 11
        '
        'Y4S2OLCO
        '
        Me.Y4S2OLCO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S2OLCO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S2OLCO.Course_Code = "Open"
        Me.Y4S2OLCO.Course_Grade = 0R
        Me.Y4S2OLCO.Course_Name = "Elective"
        Me.Y4S2OLCO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S2OLCO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Open_Elective
        Me.Y4S2OLCO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S2OLCO.Location = New System.Drawing.Point(785, 102)
        Me.Y4S2OLCO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S2OLCO.Name = "Y4S2OLCO"
        Me.Y4S2OLCO.Pre_Requisite = Nothing
        Me.Y4S2OLCO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S2OLCO.TabIndex = 10
        '
        'Y4S1PR1CO
        '
        Me.Y4S1PR1CO.BackColor = System.Drawing.Color.SkyBlue
        Me.Y4S1PR1CO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Y4S1PR1CO.Course_Code = "Professionally"
        Me.Y4S1PR1CO.Course_Grade = 0R
        Me.Y4S1PR1CO.Course_Name = "Related"
        Me.Y4S1PR1CO.Course_State = CPS613_RAMS_THING.CourseObject.State.open
        Me.Y4S1PR1CO.Course_Type = CPS613_RAMS_THING.CourseObject.CourseType.Pro_Related
        Me.Y4S1PR1CO.Cursor = System.Windows.Forms.Cursors.Help
        Me.Y4S1PR1CO.Location = New System.Drawing.Point(43, 2)
        Me.Y4S1PR1CO.Margin = New System.Windows.Forms.Padding(4)
        Me.Y4S1PR1CO.Name = "Y4S1PR1CO"
        Me.Y4S1PR1CO.Pre_Requisite = Nothing
        Me.Y4S1PR1CO.Size = New System.Drawing.Size(227, 93)
        Me.Y4S1PR1CO.TabIndex = 9
        '
        'Enrollment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1629, 669)
        Me.Controls.Add(Me.MinorsButton)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Year1CloseButton)
        Me.Controls.Add(Me.Year1OpenButton)
        Me.Controls.Add(Me.Year1Label)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Year1Panel)
        Me.Controls.Add(Me.Y2BigPanel)
        Me.Controls.Add(Me.Year3BigPanel)
        Me.Controls.Add(Me.Year4BigPanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Enrollment"
        Me.Text = "Compupter Science Program"
        Me.Year1Panel.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Year2Panel.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Y2BigPanel.ResumeLayout(False)
        Me.Y2BigPanel.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PassedPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Year3BigPanel.ResumeLayout(False)
        Me.Year3BigPanel.PerformLayout()
        Me.Year3Panel.ResumeLayout(False)
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Year4BigPanel.ResumeLayout(False)
        Me.Year4BigPanel.PerformLayout()
        Me.Year4Panel.ResumeLayout(False)
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Year1Label As Label
    Friend WithEvents Year2Label As Label
    Friend WithEvents MTH110CO As CourseObject
    Friend WithEvents Year1Panel As Panel
    Friend WithEvents CPS209CO As CourseObject
    Friend WithEvents CPS109CO As CourseObject
    Friend WithEvents MTH207CO As CourseObject
    Friend WithEvents PCS110CO As CourseObject
    Friend WithEvents LL1CO As CourseObject
    Friend WithEvents LL2CO As CourseObject
    Friend WithEvents CPS412CO As CourseObject
    Friend WithEvents CPS213CO As CourseObject
    Friend WithEvents CPS310CO As CourseObject
    Friend WithEvents Year2Panel As Panel
    Friend WithEvents CPS506CO As CourseObject
    Friend WithEvents CPS305CO As CourseObject
    Friend WithEvents CPS420CO As CourseObject
    Friend WithEvents CMN300CO As CourseObject
    Friend WithEvents OE1CO As CourseObject
    Friend WithEvents OE2CO As CourseObject
    Friend WithEvents CPS406CO As CourseObject
    Friend WithEvents CPS393CO As CourseObject
    Friend WithEvents CPS590CO As CourseObject
    Friend WithEvents MTH108CO As CourseObject
    Friend WithEvents Year1OpenButton As Button
    Friend WithEvents Year2OpenButton As Button
    Friend WithEvents Year1CloseButton As Button
    Friend WithEvents Year2CloseButton As Button
    Friend WithEvents Y2BigPanel As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PassedPictureBox As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Y2S2AddButton As Button
    Friend WithEvents Y2S1AddButton As Button
    Friend WithEvents Y2S26thCO As CourseObject
    Friend WithEvents Y2S16thCO As CourseObject
    Friend WithEvents Year3Label As Label
    Friend WithEvents Year4Label As Label
    Friend WithEvents Year3BigPanel As Panel
    Friend WithEvents Year3CloseButton As Button
    Friend WithEvents Year3OpenButton As Button
    Friend WithEvents Year3Panel As Panel
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents CPS616CO As CourseObject
    Friend WithEvents CPS510CO As CourseObject
    Friend WithEvents Y3S2PR1CO As CourseObject
    Friend WithEvents CPS721CO As CourseObject
    Friend WithEvents LL3CO As CourseObject
    Friend WithEvents UL1CO As CourseObject
    Friend WithEvents Y3S2PR2CO As CourseObject
    Friend WithEvents CPS633CO As CourseObject
    Friend WithEvents CPS706CO As CourseObject
    Friend WithEvents Y3S1PRCO As CourseObject
    Friend WithEvents MinorsButton As Button
    Friend WithEvents Year4BigPanel As Panel
    Friend WithEvents Year4CloseButton As Button
    Friend WithEvents Year4OpenButton As Button
    Friend WithEvents Year4Panel As Panel
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents Y4S2PR3CO As CourseObject
    Friend WithEvents Y4S1PR3CO As CourseObject
    Friend WithEvents Y4S2PR1CO As CourseObject
    Friend WithEvents Y4S1PR2CO As CourseObject
    Friend WithEvents Y4S1ULCO As CourseObject
    Friend WithEvents Y4S2ULCO As CourseObject
    Friend WithEvents Y4S2PR2CO As CourseObject
    Friend WithEvents Y4S1OLCO As CourseObject
    Friend WithEvents Y4S2OLCO As CourseObject
    Friend WithEvents Y4S1PR1CO As CourseObject
End Class
