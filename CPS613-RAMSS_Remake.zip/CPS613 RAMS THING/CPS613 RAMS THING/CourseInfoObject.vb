﻿Public Class CourseInfoObject
    Private Sub CourseInfoObject_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Unit_Click(sender As Object, e As EventArgs) Handles Unit.Click

    End Sub

    Private Sub Status_Click(sender As Object, e As EventArgs) Handles Status.Click

    End Sub

    Private Sub NameCheckBox_CheckedChanged(sender As Object, e As EventArgs) Handles NameCheckBox.CheckedChanged

    End Sub
End Class
